//
//  ExampleViewController.swift
//  FuturaeDemo
//
//  Created by Armend Hasani on 6.12.23.
//  Copyright © 2023 Futurae. All rights reserved.
//

import UIKit

class ExampleViewController: UIViewController, ExampleQRCodeReaderDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [unowned self] in
            // Normally you would call this after pressing a button or other trigger
            // in this example we're just gonna show the scanner after 2 seconds
            presentQRCodeController(with: .enrollment)
        }
    }
    
    func presentQRCodeController(with QRCodeType: QRCodeType) {
        let qrcodeVC = ExampleQRCodeViewController(title: "SCAN", QRCodeType: QRCodeType)
        qrcodeVC.delegate = self
        let navigationController = UINavigationController(rootViewController: qrcodeVC)
        present(navigationController, animated: true, completion: nil)
    }

    // ExampleQRCodeReaderDelegate
    func reader(_ reader: ExampleQRCodeViewController, didScanResult result: String?) {
        // TODO: Handle the QRCode result
        reader.stopScanning()
        
        print("SCAN RESULT: \(result ?? "N/A")/")

        switch reader.QRCodeType {
        case .enrollment:
            // use result for enroll
            break
        case .onlineAuth:
            // use result for online auth
            break
        case .offlineAuth:
            // use result for offline auth
            break
        case .generic:
            // handle generic
            break
        }
        
        self.dismiss(animated: true)
    }
    
    func readerDidCancel(_ reader: ExampleQRCodeViewController) {
        //
    }

}
